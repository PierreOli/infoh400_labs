# infoh400-labs2022

Code for the Medical Information Systems labs (2021-2022).

This code will be updated during the year to show a working solution of the labs. This should not be taken as a unique (or even as "the best") solution.

Code for the FHIRServer -> https://github.com/adfoucart/FHIRServer2022
